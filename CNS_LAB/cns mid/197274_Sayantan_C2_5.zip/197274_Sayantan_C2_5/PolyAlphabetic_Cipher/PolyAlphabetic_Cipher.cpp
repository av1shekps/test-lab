#include<bits/stdc++.h>
using namespace std;
void encrypt(string &str,string key)
{
    int n=key.size();
    int count=0;
    for(int i=0;i<str.size();i++)
    {
        if(str[i]==' ')
        continue;
        str[i]='a'+(str[i]-97+key[count%n]-97)%26;
        count++;
    }
        
}
void decrypt(string &str,string key)
{
    int n=key.size();
    int count=0;
    for(int i=0;i<str.size();i++)
    {
        if(str[i]==' ')
        continue;
        str[i]='a'+(str[i]-97-(key[count%n]-97)+26)%26;
        count++;
    }
}
string removespaces(string str)
{
    string temp="";
    for(int i=0;i<str.size();i++)
    {
        if(!(str[i]==' '))
        temp+=str[i];
    }
    return temp;
}
int main()
{
    string str,key,temp;
    cout<<"Enter the plain text to be encrypted : "<<endl;
    getline(cin,str);
    temp=removespaces(str);
    cout<<"Enter the key : "<<endl;
    cin>>key;
    encrypt(temp,key);
    cout<<"On Encryption the cipher text is : "<<temp<<endl;
    decrypt(temp,key);
    cout<<"On Decryption the plain text is : "<<temp<<endl;
    return 0;
}