#include<gmp.h>
#include<time.h>
#include<stdio.h>
#include<stdbool.h>
bool isprime(mpz_t n,mpz_t r,mpz_t d,mpz_t temp,mpz_t rand_num,mpz_t rop)
{
gmp_randstate_t state;
unsigned long int seed=time(NULL);
gmp_randinit_mt(state);
gmp_randseed_ui (state,seed);
mpz_set(temp,n);
mpz_sub_ui(temp,temp,3); // set temp to n-3
mpz_urandomm (rand_num, state, temp); // generate random number from 0 to n-4
mpz_add_ui (rand_num, rand_num, 2);  // random number generated from 2 to n-2
mpz_powm(rop,rand_num,d,n);
mpz_add_ui(temp,temp,2);  // set temp to n-1
if(mpz_cmp_ui(rop,1)==0||mpz_cmp(rop,temp)==0)
    return true;      // probably prime case 

        while(mpz_cmp(d,temp))
        {
            mpz_powm_ui(rop,rop,2,n);
            mpz_mul_ui(d,d,2);           
            if(mpz_cmp_ui(rop,1)==0)
            return false;  // composite number
            if(mpz_cmp(rop,temp)==0)
            return true;   // probably prime
        }
        return false; //composite
}
void main()
{
mpz_t n,r,d,temp,rand_num,rop;
mpz_inits(n,r,d,temp,rand_num,rop,NULL);
gmp_printf("\n enter value of the number you want to test for prime : ");
gmp_scanf("%Zd",n);
if(mpz_even_p(n))  // the number given is even itself
{
    gmp_printf("\n THe given number is composite \n ");
    return;
}
mpz_set(temp,n);
mpz_set_ui(r,0);
mpz_sub_ui(temp,temp,1);
while(mpz_even_p(temp))   // if number is even 
{
    mpz_add_ui(r,r,1);
    mpz_cdiv_q_ui(temp,temp,2);
}
mpz_set(d,temp);
int k=10; 
for(int i=0;i<k;i++)
    if(!isprime(n,r,d,temp,rand_num,rop))
    {
    gmp_printf("\n THe given number is composite \n ");
    return; 
    }
gmp_printf("\n THe given number is prime \n ");
return ;	
}
